﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Threading;

class Program
{
    private static readonly HttpClient client = new HttpClient();
    private static string apiUrl = "http://localhost:5072/api/airquality";
    private static string intervalApiUrl = "http://localhost:5072/api/simulation/setInterval";
    private static Random rand = new Random();

    static async Task Main()
    {
        Console.WriteLine("Starting AQI Data Simulation...");

        while (true)
        {
            await GenerateAndSendData();
            int waitTime = await GetGenerationInterval();
            Console.WriteLine($"Waiting {waitTime / 1000} seconds before next update...");
            Thread.Sleep(waitTime);
        }
    }

    static async Task<int> GetGenerationInterval()
    {
        string getIntervalApiUrl = "http://localhost:5072/api/simulation/getInterval"; // Use the correct API

        try
        {
            HttpResponseMessage response = await client.GetAsync(getIntervalApiUrl);
            if (response.IsSuccessStatusCode)
            {
                string json = await response.Content.ReadAsStringAsync();
                var config = JsonConvert.DeserializeObject<IntervalConfig>(json);
                return config.GenerationInterval;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"⚠️ Failed to fetch interval: {ex.Message}");
        }

        return 30000; // Default to 1 min if API fails
    }


    static async Task GenerateAndSendData()
    {
        List<int> sensorIds = new List<int> { 1, 2, 3, 4, 5, 6 };

        foreach (int sensorId in sensorIds)
        {
            var data = new
            {
                SensorID = sensorId,
                AQI = rand.Next(0, 500),
                PM25 = rand.Next(5, 150) / 1.5m,
                PM10 = rand.Next(10, 200) / 1.5m,
                Timestamp = DateTime.UtcNow
            };

            string json = JsonConvert.SerializeObject(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                HttpResponseMessage response = await client.PutAsync($"{apiUrl}/{sensorId}", content);
                Console.WriteLine(response.IsSuccessStatusCode
                    ? $"✅ Data sent for Sensor {sensorId}: AQI {data.AQI}, PM2.5 {data.PM25}, PM10 {data.PM10}"
                    : $"❌ Error sending data for Sensor {sensorId}: {response.StatusCode}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Exception: {ex.Message}");
            }
        }
    }

    class IntervalConfig
    {
        public int GenerationInterval { get; set; }
    }
}
