// Initialize the map
const map = L.map('map', MAP_CONFIG);

// Add OpenStreetMap tile layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Store markers and sensor data
let sensorMarkers = {};
let sensorData = {};

// Initialize charts
let pm25Chart = null;
let pm10Chart = null;
let historicalChart = null;

// Function to get AQI level based on value
function getAQILevel(value) {
    if (value <= AQI_LEVELS.GOOD.max) return AQI_LEVELS.GOOD;
    if (value <= AQI_LEVELS.MODERATE.max) return AQI_LEVELS.MODERATE;
    return AQI_LEVELS.UNHEALTHY;
}

// Fetch sensors from the backend API
async function fetchSensors() {
    try {
        const response = await fetch("http://localhost:5072/api/sensors/with-data");
        if (!response.ok) {
            throw new Error("Failed to fetch sensor data");
        }
        const sensors = await response.json();
        return sensors.map(sensor => ({
            id: sensor.SensorID,
            name: sensor.SensorName,
            location: [sensor.Latitude, sensor.Longitude],
            isActive: sensor.Status === "Active",
            aqi: sensor.LastReading, // Latest AQI reading from the sensor
            pm25: sensor.PM25,
            pm10: sensor.PM10,
            timestamp: sensor.Timestamp
        }));
    } catch (error) {
        console.error("Error fetching sensors:", error);
        return [];
    }
}

// Function to create marker icon
function createMarkerIcon(aqi) {
    const level = getAQILevel(aqi);
    return L.divIcon({
        className: 'custom-marker',
        html: `<div style="background-color: ${level.color}; width: 24px; height: 24px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">
            <div style="font-size: 12px; text-align: center; line-height: 22px; color: ${level.color === '#ffff00' ? '#000' : '#fff'}">${Math.round(aqi)}</div>
        </div>`,
        iconSize: [24, 24]
    });
}

// Function to create popup content
function createPopupContent(sensor, aqi) {
    const level = getAQILevel(aqi);
    return `
        <div class="sensor-popup">
            <h4>${sensor.name}</h4>
            <div class="location">${sensor.location.join(', ')}</div>
            <div class="aqi-value">${Math.round(aqi)}</div>
            <div class="aqi-status" style="background-color: ${level.color}; color: ${level.color === '#ffff00' ? '#000' : '#fff'}">
                ${level.label}
            </div>
            <div class="update-time">Last updated: ${new Date(sensor.timestamp).toLocaleString()}</div>
            <button class="btn btn-sm btn-primary w-100 mt-2" onclick="showSensorDetails('${sensor.id}')">
                View Details
            </button>
        </div>
    `;
}

async function updateSensorData() {
    try {
        const sensors = await fetchSensors();

        // Remove existing markers
        for (const marker of Object.values(sensorMarkers)) {
            map.removeLayer(marker);
        }
        sensorMarkers = {}; // Clear the markers object

        sensors.forEach(sensor => {
            sensorData[sensor.id] = {
                current: sensor.aqi,
                pm25: sensor.pm25,
                pm10: sensor.pm10,
                timestamp: sensor.timestamp
            };

            const marker = L.marker(sensor.location, {
                icon: createMarkerIcon(sensor.aqi)
            }).addTo(map);

            marker.bindPopup(createPopupContent(sensor, sensor.aqi));
            sensorMarkers[sensor.id] = marker;
        });

    } catch (error) {
        console.error("Error updating sensor data:", error);
    }
}


// Function to show sensor details
function showSensorDetails(sensorId) {
    const sensor = sensorData[sensorId];

    if (!sensor) return;

    // Update sensor info
    document.getElementById('sensor-info').innerHTML = `
        <h6>Sensor ID: ${sensorId}</h6>
        <p class="mb-1">Current AQI: ${Math.round(sensor.current)}</p>
        <p>PM2.5: ${sensor.pm25} µg/m³</p>
        <p>PM10: ${sensor.pm10} µg/m³</p>
        <p>Status: ${getAQILevel(sensor.current).label}</p>
        <p>Last Updated: ${new Date(sensor.timestamp).toLocaleString()}</p>
    `;

    // Update PM2.5 Chart
    if (pm25Chart) pm25Chart.destroy();
    pm25Chart = new Chart(document.getElementById('pm25-chart'), {
        type: 'bar',
        data: {
            labels: ['PM2.5'],
            datasets: [{
                label: 'PM2.5 µg/m³',
                data: [sensor.pm25],
                backgroundColor: '#007bff'
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Update PM10 Chart
    if (pm10Chart) pm10Chart.destroy();
    pm10Chart = new Chart(document.getElementById('pm10-chart'), {
        type: 'bar',
        data: {
            labels: ['PM10'],
            datasets: [{
                label: 'PM10 µg/m³',
                data: [sensor.pm10],
                backgroundColor: '#28a745'
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Update Historical Chart
    if (historicalChart) historicalChart.destroy();
    historicalChart = new Chart(document.getElementById('historical-chart'), {
        type: 'line',
        data: {
            labels: Array(12).fill(0).map((_, i) => `Month ${i + 1}`),
            datasets: [{
                label: 'Monthly Average PM2.5',
                data: Array(12).fill(0).map(() => Math.random() * 100),
                backgroundColor: '#00e400'
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Auto-update sensor data every minute
setInterval(updateSensorData, 60000); // 60 seconds
updateSensorData(); // Initial data load
