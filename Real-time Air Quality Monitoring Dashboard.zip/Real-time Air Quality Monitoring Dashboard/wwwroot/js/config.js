// Map Configuration
const MAP_CONFIG = {
    center: [6.9271, 79.8612], // Colombo coordinates
    zoom: 12,
    maxZoom: 18,
    minZoom: 10
};

// AQI Thresholds and Colors
const AQI_LEVELS = {
    GOOD: {
        min: 0,
        max: 50,
        color: '#00e400',
        label: 'Good'
    },
    MODERATE: {
        min: 51,
        max: 100,
        color: '#ffff00',
        label: 'Moderate'
    },
    UNHEALTHY_SENSITIVE: {
        min: 101,
        max: 150,
        color: '#ff7e00',
        label: 'Unhealthy for Sensitive Groups'
    },
    UNHEALTHY: {
        min: 151,
        max: 200,
        color: '#ff0000',
        label: 'Unhealthy'
    }
};

// Fetch sensors from the backend API
async function fetchSensors() {
    try {
        const response = await fetch("http://localhost:5072/api/sensors/with-data");
        if (!response.ok) {
            throw new Error("Failed to fetch sensor data");
        }
        const sensors = await response.json();
        return sensors.map(sensor => ({
            id: sensor.SensorID,
            name: sensor.SensorName,
            location: [sensor.Latitude, sensor.Longitude],
            isActive: sensor.Status === "Active",
            aqi: sensor.LastReading, // Latest AQI reading from the sensor
            pm25: sensor.PM25,
            pm10: sensor.PM10,
            timestamp: sensor.Timestamp
        }));
    } catch (error) {
        console.error("Error fetching sensors:", error);
        return [];
    }
}

export { MAP_CONFIG, AQI_LEVELS, fetchSensors };
