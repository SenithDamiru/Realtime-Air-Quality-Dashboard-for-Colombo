﻿using AirQualityAPI.Data;
using AirQualityAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/airquality")]
[ApiController]
public class AirQualityDataController : ControllerBase
{
    private readonly AppDbContext _context;

    public AirQualityDataController(AppDbContext context)
    {
        _context = context;
    }

    // Get latest AQI data for all sensors
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AirQualityData>>> GetLatestAQI()
    {
        var data = await _context.AirQualityData
            .OrderByDescending(aq => aq.Timestamp)
            .ToListAsync();

        return data;
    }

    // Get AQI data for a specific sensor
    [HttpGet("{sensorId}")]
    public async Task<ActionResult<IEnumerable<AirQualityData>>> GetSensorAQI(int sensorId)
    {
        var data = await _context.AirQualityData
            .Where(aq => aq.SensorID == sensorId)
            .OrderByDescending(aq => aq.Timestamp)
            .ToListAsync();

        if (data == null || !data.Any()) return NotFound();
        return data;
    }

    // Add new AQI data (Simulated or Real API)
    [HttpPost]
    public async Task<ActionResult<AirQualityData>> AddAQIData(AirQualityData data)
    {
        // Log the received data for debugging
        Console.WriteLine($"Received Data: SensorID={data.SensorID}, AQI={data.AQI}, PM25={data.PM25}, PM10={data.PM10}, Timestamp={data.Timestamp}");

        // Ensure the SensorID exists in the database
        var sensorExists = await _context.Sensors.AnyAsync(s => s.SensorID == data.SensorID);
        if (!sensorExists)
        {
            return BadRequest("Sensor with the provided ID does not exist.");
        }

        // Additional validation
        if (data.AQI < 0 || data.AQI > 500)
        {
            return BadRequest("AQI value must be between 0 and 500.");
        }

        if (data.PM25 < 0 || data.PM25 > 1000)
        {
            return BadRequest("PM2.5 value is out of valid range.");
        }

        if (data.PM10 < 0 || data.PM10 > 1000)
        {
            return BadRequest("PM10 value is out of valid range.");
        }

        _context.AirQualityData.Add(data);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetSensorAQI), new { sensorId = data.SensorID }, data);
    }


    // Update AQI data for a specific sensor
    [HttpPut("{sensorId}")]
    public async Task<IActionResult> UpdateAQIData(int sensorId, AirQualityData data)
    {
        // Ensure the sensor exists in the database
        var sensorExists = await _context.Sensors.AnyAsync(s => s.SensorID == data.SensorID);
        if (!sensorExists)
        {
            return BadRequest("Sensor with the provided ID does not exist.");
        }

        // Find the existing data for the given sensor
        var existingData = await _context.AirQualityData
            .FirstOrDefaultAsync(aq => aq.SensorID == sensorId);

        if (existingData == null)
        {
            return NotFound($"No AQI data found for Sensor {sensorId}");
        }

        // Update the data
        existingData.AQI = data.AQI;
        existingData.PM25 = data.PM25;
        existingData.PM10 = data.PM10;
        existingData.Timestamp = data.Timestamp;

        // Save changes
        await _context.SaveChangesAsync();

        return NoContent(); // 204 No Content for successful update
    }
}
