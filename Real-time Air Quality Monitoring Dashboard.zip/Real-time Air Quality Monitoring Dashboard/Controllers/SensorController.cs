﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AirQualityAPI.Data;
using AirQualityAPI.Models;

[Route("api/sensors")]
[ApiController]
public class SensorController : ControllerBase
{
    private readonly AppDbContext _context;
    public SensorController(AppDbContext context) { _context = context; }

    // Get all sensors
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Sensor>>> GetSensors()
    {
        return await _context.Sensors.ToListAsync();
    }

    // Get sensor by ID
    [HttpGet("{id}")]
    public async Task<ActionResult<Sensor>> GetSensor(int id)
    {
        var sensor = await _context.Sensors.FindAsync(id);
        if (sensor == null) return NotFound();
        return sensor;
    }

    // Add new sensor
    [HttpPost]
    public async Task<ActionResult<Sensor>> AddSensor(Sensor sensor)
    {
        _context.Sensors.Add(sensor);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(GetSensor), new { id = sensor.SensorID }, sensor);
    }

    [HttpGet("active")]
    public async Task<ActionResult<IEnumerable<Sensor>>> GetActiveSensors()
    {
        return await _context.Sensors
            .Where(s => s.Status == "Active")
            .ToListAsync();
    }

    [HttpGet("active/count")]
    public async Task<ActionResult<int>> GetActiveSensorCount()
    {
        int activeSensorCount = await _context.Sensors.CountAsync(s => s.Status == "Active");
        return Ok(activeSensorCount);
    }

    [HttpPost("update-status/{id}")]
    public async Task<IActionResult> UpdateSensorStatus(int id, [FromBody] string status)
    {
        if (status != "Active" && status != "Inactive")
            return BadRequest("Invalid status. Allowed values: 'Active', 'Inactive'.");

        var sensor = await _context.Sensors.FindAsync(id);
        if (sensor == null) return NotFound("Sensor not found.");

        if (status == "Active" && sensor.Status != "Active")
        {
            sensor.ActivatedAt = DateTime.UtcNow;
            sensor.DeactivatedAt = null;
        }
        else if (status == "Inactive" && sensor.Status != "Inactive")
        {
            sensor.DeactivatedAt = DateTime.UtcNow;
        }

        sensor.Status = status;
        await _context.SaveChangesAsync();

        return Ok(sensor);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateSensor(int id, [FromBody] Sensor updatedSensor)
    {
        if (id != updatedSensor.SensorID)
        {
            return BadRequest("Sensor ID mismatch.");
        }

        var sensor = await _context.Sensors.FindAsync(id);
        if (sensor == null)
        {
            return NotFound("Sensor not found.");
        }

        sensor.SensorName = updatedSensor.SensorName;
        sensor.LocationName = updatedSensor.LocationName;
        sensor.Latitude = updatedSensor.Latitude;
        sensor.Longitude = updatedSensor.Longitude;
        sensor.Status = updatedSensor.Status;

        if (updatedSensor.Status == "Inactive" && sensor.Status != "Inactive")
        {
            sensor.DeactivatedAt = DateTime.UtcNow;
        }
        else if (updatedSensor.Status == "Active" && sensor.Status != "Active")
        {
            sensor.ActivatedAt = DateTime.UtcNow;
        }

        try
        {
            await _context.SaveChangesAsync();
            return Ok(sensor);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, "Error updating sensor: " + ex.Message);
        }
    }


    [HttpGet("system-uptime")]
    public async Task<IActionResult> GetSystemUptime()
    {
        var totalSensors = await _context.Sensors.CountAsync();
        var activeSensors = await _context.Sensors.CountAsync(s => s.Status == "Active");

        if (totalSensors == 0)
        {
            return Ok(new { uptime = 0, message = "No sensors available." });
        }

        double uptimePercentage = ((double)activeSensors / totalSensors) * 100;

        return Ok(new { uptime = uptimePercentage });
    }

    [HttpGet("test-connection")]
    public async Task<IActionResult> TestDatabaseConnection()
    {
        try
        {
            await _context.Database.CanConnectAsync();
            return Ok("Database connection is successful!");
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Database connection failed: {ex.Message}");
        }
    }


    [HttpGet("with-data")]
    public async Task<IActionResult> GetSensorsWithData()
    {
        var sensors = await _context.Sensors
            .Include(s => s.AirQualityData)
            .ToListAsync(); // Fetch all sensors and their data

        var result = sensors.Select(s => new
        {
            s.SensorID,
            s.SensorName,
            s.LocationName,
            s.Latitude,
            s.Longitude,
            s.Status,
            LastReading = s.AirQualityData != null && s.AirQualityData.Any()
                ? s.AirQualityData.OrderByDescending(d => d.Timestamp).First().AQI
                : 0, // Default value if no data

            PM25 = s.AirQualityData != null && s.AirQualityData.Any()
                ? s.AirQualityData.OrderByDescending(d => d.Timestamp).First().PM25
                : 0,

            PM10 = s.AirQualityData != null && s.AirQualityData.Any()
                ? s.AirQualityData.OrderByDescending(d => d.Timestamp).First().PM10
                : 0,

            Timestamp = s.AirQualityData != null && s.AirQualityData.Any()
                ? s.AirQualityData.OrderByDescending(d => d.Timestamp).First().Timestamp
                : DateTime.MinValue
        }).ToList();

        return Ok(result);
    }

    // New endpoint to fetch AQI for a specific sensor by sensorId
    [HttpGet("aqi")]
    public async Task<IActionResult> GetAQIBySensorId([FromQuery] int sensorId)
    {
        var sensor = await _context.Sensors
            .Include(s => s.AirQualityData) // Include related AQI data
            .FirstOrDefaultAsync(s => s.SensorID == sensorId);

        if (sensor == null)
        {
            return NotFound("Sensor not found.");
        }

        // Get the most recent AQI value
        var latestAQI = sensor.AirQualityData?.OrderByDescending(d => d.Timestamp).FirstOrDefault()?.AQI ?? 0;

        return Ok(new { aqi = latestAQI });
    }





}
