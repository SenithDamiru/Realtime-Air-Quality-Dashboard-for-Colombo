﻿using AirQualityAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AirQualityAPI.Data;
using Newtonsoft.Json;


[Route("api/users")]
[ApiController]
public class UsersController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IConfiguration _configuration;

    public UsersController(AppDbContext context, IConfiguration configuration)
    {
        _context = context;
        _configuration = configuration;
    }

    // Register a new user
    [HttpPost("register")]
    public async Task<IActionResult> Register(User user)
    {
        if (await _context.Users.AnyAsync(u => u.Email == user.Email))
        {
            return BadRequest("Email is already in use.");
        }

        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(user.PasswordHash); // Hash password
        user.Role = user.Role ?? "Public";  // Default role
        user.Status = "Active"; // Default status

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return Ok(new { message = "User registered successfully." });

    }

    // Login and generate JWT token
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == request.Email);
        if (user == null || !BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash))
        {
            return Unauthorized("Invalid credentials.");
        }

        if (user.Status != "Active")
        {
            return Unauthorized("User is inactive.");
        }

        var token = GenerateJwtToken(user);
        return Ok(new { Token = token, Role = user.Role, Name = user.Name });
    }

    // Fetch all users (Admin only)
    // GET: api/users
    [HttpGet]
    public async Task<IActionResult> GetUsers()
    {
        try
        {
            var users = await _context.Users.ToListAsync();  // Replace 'Users' with your actual DbSet
            return Ok(users);  // Return users in response
        }
        catch (Exception ex)
        {
            return BadRequest("Error fetching users: " + ex.Message);  // Handle errors
        }
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetUserById(int id)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null)
        {
            return NotFound();
        }
        return Ok(user);
    }


    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateUser(int id, [FromBody] User updatedUser)
    {
        try
        {
            Console.WriteLine($"Received Update Request: {JsonConvert.SerializeObject(updatedUser)}");

            if (updatedUser == null)
            {
                return BadRequest(new { message = "Invalid user data received" });
            }

            if (id != updatedUser.UserID)
            {
                return BadRequest(new { message = "User ID mismatch" });
            }

            var existingUser = await _context.Users.FindAsync(id);
            if (existingUser == null)
            {
                return NotFound(new { message = "User not found" });
            }

            // Update user details
            existingUser.Name = updatedUser.Name;
            existingUser.Email = updatedUser.Email;
            existingUser.Role = updatedUser.Role;
            existingUser.Status = updatedUser.Status;

            // Only update the password if a new password is provided
        if (!string.IsNullOrWhiteSpace(updatedUser.PasswordHash))
        {
            existingUser.PasswordHash = BCrypt.Net.BCrypt.HashPassword(updatedUser.PasswordHash);
        }

            await _context.SaveChangesAsync();

            return Ok(new { message = "User updated successfully" });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error updating user: {ex}");
            return StatusCode(500, new { message = "Internal Server Error", error = ex.ToString() });
        }
    }

    [HttpGet("alluser")]
    public async Task<ActionResult<int>> GetActiveSensorCount()
    {
        int allUserCount = await _context.Users.CountAsync();
        return Ok(allUserCount);
    }




    [HttpDelete("{id}")]
    
    public async Task<IActionResult> DeleteUser(int id)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null)
        {
            return NotFound(new { message = "User not found" });
        }

        _context.Users.Remove(user);
        await _context.SaveChangesAsync();
        // Log successful deletion for debugging
        Console.WriteLine($"User with ID {id} deleted");

        return Ok(new { message = "User deleted successfully" });
    }


    // Helper method to generate JWT token
    private string GenerateJwtToken(User user)
    {
        var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]);
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.UserID.ToString()),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.Role, user.Role)
        };

        var token = new JwtSecurityToken(
            claims: claims,
            expires: DateTime.UtcNow.AddHours(2),
            signingCredentials: new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256)
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}

// Models for requests
public class LoginRequest
{
    public string Email { get; set; }
    public string Password { get; set; }
}

public class RoleUpdateRequest
{
    public string Role { get; set; }
}
