﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Threading.Tasks;

[Route("api/simulation")]
[ApiController]
public class SimulationController : ControllerBase
{
    private static Process _simulationProcess = null;

    // Start Simulation
    [HttpPost("start")]
    public IActionResult StartSimulation()
    {
        if (_simulationProcess == null || _simulationProcess.HasExited)
        {
            _simulationProcess = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "C:\\Users\\senith\\Desktop\\SE2 proj\\AQISimulator\\bin\\Debug\\AQISimulator.exe",
                    //RedirectStandardOutput = true,
                    UseShellExecute = true, // Allow opening a new console window
                    CreateNoWindow = false  // Ensure the window appears
                }
            };
            _simulationProcess.Start();
            return Ok(new { message = "Simulation started" });
        }
        return BadRequest(new { message = "Simulation is already running" });
    }

    // Stop Simulation
    [HttpPost("stop")]
    public IActionResult StopSimulation()
    {
        if (_simulationProcess != null && !_simulationProcess.HasExited)
        {
            _simulationProcess.Kill();
            _simulationProcess.Dispose();
            _simulationProcess = null;
            return Ok(new { message = "Simulation stopped" });
        }
        return BadRequest(new { message = "No simulation running" });
    }

    // Get Simulation Status
    [HttpGet("status")]
    public IActionResult GetSimulationStatus()
    {
        bool isRunning = _simulationProcess != null && !_simulationProcess.HasExited;
        return Ok(new { running = isRunning });
    }


    [HttpPost("setInterval")]
    public IActionResult SetGenerationInterval([FromBody] IntervalConfig config)
    {
        if (config == null || config.GenerationInterval <= 0)
        {
            return BadRequest(new { message = "Invalid interval value" });
        }

        SimulationSettings.GenerationInterval = config.GenerationInterval;
        return Ok(new { message = "Generation interval updated" });
    }

    // Store the interval globally
    public static class SimulationSettings
    {
        public static int GenerationInterval { get; set; } = 60000; // Default: 1 min
    }

    // DTO class
    public class IntervalConfig
    {
        public int GenerationInterval { get; set; } // In milliseconds
    }

    [HttpGet("getInterval")]
    public IActionResult GetGenerationInterval()
    {
        return Ok(new { GenerationInterval = SimulationSettings.GenerationInterval });
    }


}
