﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AirQualityAPI.Data;
using AirQualityAPI.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Reflection.PortableExecutable;

namespace AirQualityAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlertsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AlertsController(AppDbContext context)
        {
            _context = context;
        }

        // Add a new Alert Rule
        [HttpPost("create")]
        public async Task<IActionResult> CreateAlert([FromBody] Alert alert)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _context.Alerts.Add(alert);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetAlert), new { id = alert.AlertID }, alert);
        }

        // Get an alert by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetAlert(int id)
        {
            var alert = await _context.Alerts.FindAsync(id);
            if (alert == null)
                return NotFound();

            return Ok(alert);
        }
        [HttpGet]
        public async Task<IActionResult> GetAllAlerts()
        {
            var alerts = await _context.Alerts
                .Select(a => new
                {
                    AlertID = a.AlertID,
                    AlertType = a.AlertType ?? "No alert type",  // Default value if AlertType is NULL
                    AQIThreshold = a.AQIThreshold ?? 0,  // Default if NULL (e.g., 0 for AQI threshold)
                    Priority = a.Priority ?? "No priority",  // Default if NULL
                    NotificationMethods = a.NotificationMethods ?? "No methods",  // Default if NULL
                    AlertMessage = a.AlertMessage ?? "No alert message",  // Default if NULL
                    Status = a.Status,  // Default if NULL
                    CreatedAt = a.CreatedAt.ToString("yyyy-MM-dd HH:mm:ss")  // Formatting DateTime if necessary
                })
                .ToListAsync();

            return Ok(alerts);
        }

        [HttpGet("active/count")]
        public async Task<ActionResult<int>> GetActiveAlertsCount()
        {
            int activeAlertCount = await _context.Alerts.CountAsync(a => a.Status == "Active");
            return Ok(activeAlertCount);
        }





        // Delete an alert
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAlert(int id)
        {
            var alert = await _context.Alerts.FindAsync(id);
            if (alert == null)
                return NotFound();

            _context.Alerts.Remove(alert);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Edit an existing Alert Rule
        [HttpPut("{id}")]
        public async Task<IActionResult> EditAlert(int id, [FromBody] Alert alert)
        {
            if (id != alert.AlertID)
            {
                return BadRequest("Alert ID mismatch");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existingAlert = await _context.Alerts.FindAsync(id);
            if (existingAlert == null)
            {
                return NotFound();
            }

            // Update the existing alert's properties
            existingAlert.AlertType = alert.AlertType;
            existingAlert.AQIThreshold = alert.AQIThreshold;
            existingAlert.Priority = alert.Priority;
            existingAlert.NotificationMethods = alert.NotificationMethods;
            existingAlert.AlertMessage = alert.AlertMessage;
            existingAlert.Status = alert.Status; // Updating Status as well
            existingAlert.CreatedAt = alert.CreatedAt; // You might want to set this as DateTime.UtcNow instead, based on your business logic

            // Save changes to the database
            _context.Alerts.Update(existingAlert);
            await _context.SaveChangesAsync();

            return Ok(existingAlert); // Return the updated alert
        }

    }
}
