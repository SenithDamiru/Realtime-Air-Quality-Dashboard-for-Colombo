﻿namespace AirQualityAPI.Data
{
    using Microsoft.EntityFrameworkCore;
    using AirQualityAPI.Models;

    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Sensor> Sensors { get; set; }
        public DbSet<AirQualityData> AirQualityData { get; set; }
        public DbSet<Alert> Alerts { get; set; }
    }
}
