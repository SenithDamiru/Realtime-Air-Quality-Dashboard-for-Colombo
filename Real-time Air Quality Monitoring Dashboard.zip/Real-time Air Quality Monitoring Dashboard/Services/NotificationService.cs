﻿using System;
using System.Threading.Tasks;
using AirQualityAPI.Models;
using System.Net.Mail;
using System.Net;

namespace AirQualityAPI.Services
{
    public class NotificationService
    {
        public async Task SendNotification(Alert alert, string message)
        {
            var methods = alert.NotificationMethods.Split(',');

            foreach (var method in methods)
            {
                switch (method.Trim())
                {
                    case "Email":
                        await SendEmailNotification(alert, message);
                        break;
                    case "Dashboard":
                        Console.WriteLine($"Dashboard Alert: {message}");
                        break;
                    case "SMS":
                        await SendSmsNotification(alert, message);
                        break;
                }
            }
        }

        private async Task SendEmailNotification(Alert alert, string message)
        {
            try
            {
                var smtpClient = new SmtpClient("smtp.example.com") // Replace with your SMTP server
                {
                    Port = 587,
                    Credentials = new NetworkCredential("your-email@example.com", "your-password"),
                    EnableSsl = true,
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress("your-email@example.com"),
                    Subject = "Air Quality Alert",
                    Body = message,
                    IsBodyHtml = false,
                };
                mailMessage.To.Add("recipient@example.com"); // Replace with dynamic email addresses

                await smtpClient.SendMailAsync(mailMessage);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Email Notification Failed: {ex.Message}");
            }
        }

        private async Task SendSmsNotification(Alert alert, string message)
        {
            Console.WriteLine($"SMS Sent: {message} (Integrate with Twilio or other SMS providers)");
            await Task.CompletedTask;
        }
    }
}
