﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using AirQualityAPI.Data;
using AirQualityAPI.Models;

namespace AirQualityAPI.Services
{
    public class AlertService
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly NotificationService _notificationService;
        private readonly EmailService _emailService;

        // ✅ Inject all required dependencies in a single constructor
        public AlertService(IServiceScopeFactory scopeFactory, NotificationService notificationService, EmailService emailService)
        {
            _scopeFactory = scopeFactory ?? throw new ArgumentNullException(nameof(scopeFactory));
            _notificationService = notificationService ?? throw new ArgumentNullException(nameof(notificationService));
            _emailService = emailService ?? throw new ArgumentNullException(nameof(emailService));
        }

        public async Task CheckAQIThresholds()
        {
            Console.WriteLine("🔍 Debug: Entered CheckAQIThresholds method");

            using (var scope = _scopeFactory?.CreateScope())
            {
                if (scope == null)
                {
                    throw new Exception("🚨 Error: _scopeFactory is null!");
                }
                Console.WriteLine("✅ Debug: Scope created successfully");

                var _context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                if (_context == null)
                {
                    throw new Exception("🚨 Error: AppDbContext could not be resolved.");
                }
                Console.WriteLine("✅ Debug: AppDbContext initialized successfully");

                // Fetch alerts
                var alerts = await _context.Alerts.ToListAsync();
                if (alerts == null || !alerts.Any())
                {
                    Console.WriteLine("⚠️ Warning: No alerts found in database.");
                    return;
                }
                Console.WriteLine($"✅ Debug: {alerts.Count} alerts loaded");

                // Fetch latest air quality data per sensor
                var sensorData = await _context.AirQualityData
                    .GroupBy(d => d.SensorID)
                    .Select(g => g.OrderByDescending(d => d.Timestamp).FirstOrDefault())
                    .ToListAsync();

                if (sensorData == null || !sensorData.Any())
                {
                    Console.WriteLine("⚠️ Warning: No sensor data found.");
                    return;
                }
                Console.WriteLine($"✅ Debug: {sensorData.Count} sensors loaded");

                foreach (var sensor in sensorData)
                {
                    foreach (var alert in alerts)
                    {
                        if (alert.AQIThreshold.HasValue && sensor.AQI >= alert.AQIThreshold)
                        {
                            if (_notificationService == null)
                            {
                                throw new Exception("🚨 Error: NotificationService is not initialized.");
                            }

                            string message = $"Alert: {alert.AlertType} - AQI {sensor.AQI} exceeded threshold {alert.AQIThreshold}.";
                            Console.WriteLine($"🚀 Sending notification: {message}");
                            await _notificationService.SendNotification(alert, message);
                        }
                    }
                }
            }

            // Send email alert
            if (_emailService != null)
            {
                string recipientEmail = "senithspecialacc@gmail.com";
                string alertMessage = "AQI has crossed the safe threshold!";
                Console.WriteLine($"📧 Sending email to {recipientEmail}");
                await _emailService.SendEmailAsync(recipientEmail, "Air Quality Alert", alertMessage);
            }
            else
            {
                throw new Exception("🚨 Error: EmailService is not initialized.");
            }
        }

    }


}

