﻿using System.ComponentModel.DataAnnotations;

namespace AirQualityAPI.Models
{
    public class AirQualityData
    {
        [Key] // This will explicitly set AQIDataID as the primary key
        public int AQIDataID { get; set; }
        public int SensorID { get; set; }
        public int AQI { get; set; }
        public decimal PM25 { get; set; }
        public decimal PM10 { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;

        public Sensor? Sensor { get; set; }
    }

}
