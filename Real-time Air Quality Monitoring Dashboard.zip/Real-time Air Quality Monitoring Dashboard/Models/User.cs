﻿namespace AirQualityAPI.Models
{
    public class User
    {
        public int UserID { get; set; }
        public string Name { get; set; }  // Updated from Username to Name
        public string Email { get; set; } // Added Email field
        public string PasswordHash { get; set; }
        public string Role { get; set; } // "Admin" or "Public"
        public string Status { get; set; } // "Active" or "Inactive"
    }


}
