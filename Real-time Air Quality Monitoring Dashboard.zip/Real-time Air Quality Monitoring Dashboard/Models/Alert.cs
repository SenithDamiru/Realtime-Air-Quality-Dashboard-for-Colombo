﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace AirQualityAPI.Models
{
    public class Alert
    {
        [Key]
        public int AlertID { get; set; }

        [Required]
        [StringLength(50)]
        public string AlertType { get; set; }  // High PM2.5, High PM10, etc.

        [JsonPropertyName("aqiThreshold")]
        public decimal? AQIThreshold { get; set; } // Nullable for system malfunctions

        [Required]
        [StringLength(10)]
        public string Priority { get; set; } // Low, Medium, High, Critical

        [Required]
        [StringLength(100)]
        public string NotificationMethods { get; set; } // Comma-separated: "Email,Dashboard"

        [Required]
        [StringLength(255)]
        public string AlertMessage { get; set; }

        // New Status Property
       
        [StringLength(10)]
        public string Status { get; set; } = "Active"; // Default value set to "Active"

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    }
}
