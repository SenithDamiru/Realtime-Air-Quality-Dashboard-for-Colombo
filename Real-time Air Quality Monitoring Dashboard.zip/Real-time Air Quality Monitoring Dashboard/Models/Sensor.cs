﻿using System.Text.Json.Serialization;

namespace AirQualityAPI.Models
{
    public class Sensor
    {
        public int SensorID { get; set; }
        public string? SensorName { get; set; }
        public string? LocationName { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public string? Status { get; set; } // "Active" or "Inactive"
        public decimal? LastReading { get; set; } // Nullable to allow NULL values
        public DateTime? ActivatedAt { get; set; }
        public DateTime? DeactivatedAt { get; set; }

        // Navigation property for related air quality data
        [JsonIgnore]
        public List<AirQualityData>? AirQualityData { get; set; }
    }


}
